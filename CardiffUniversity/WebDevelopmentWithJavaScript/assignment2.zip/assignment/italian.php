<?php

header("content-type: Access-Control-Allow-Origin: *");
header("content-type: Access-Control-Allow-Methods: POST");
header("content-type: text/javascript");




$menu = array(
    array(
        "course" => "starter",
        "name" => "Bruschetta",
        "price" => "3.99"
    ),
    array(
        "course" => "starter",
        "name" => "Fried Ravioli",
        "price" => "4.99"
    ),
    array(
        "course" => "starter",
        "name" => "Frutti De Mare",
        "price" => "6.99"
    ),
    array(
        "course" => "starter",
        "name" => "Garlic Mushrooms",
        "price" => "4.99"
    ),
    array(
        "course" => "main",
        "name" => "Spaghetti Bolognese",
        "price" => "8.99"
    ),
    array(
        "course" => "main",
        "name" => "Spaghetti Vongole",
        "price" => "9.99"
    ),
    array(
        "course" => "main",
        "name" => "Fettucine Alfredo",
        "price" => "10.99"
    ),
    array(
        "course" => "main",
        "name" => "Chicken Florentine",
        "price" => "12.99"
    ),
    array(
        "course" => "main",
        "name" => "Margheritta",
        "price" => "8.99"
    ),
    array(
        "course" => "main",
        "name" => "Sicilian",
        "price" => "9.99"
    ),
    array(
        "course" => "main",
        "name" => "Tagliatelle Carbonara",
        "price" => "8.99"
    ),
);



//    echo json_encode($obj);


echo $_GET['callback'] . '(' . json_encode($menu) . ');';
?>