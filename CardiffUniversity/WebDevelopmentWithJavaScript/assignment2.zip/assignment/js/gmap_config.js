/* CONFIGURATION ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ START */

// RATE OF ZOOM
// 0 to zoom right out, 20 to zoom right in
var gmap_zoom = 5;


// CENTRE POSITION OF THE MAP
// Change these values to the LatLng that you want the map to centre on
// NOTE:  54.5, -2.5 is the centre of the UK (including N. Ireland)
var gmap_centre = new google.maps.LatLng(38.71980474264239, 138.01025390625);


// MAPTYPE
var gmap_map_type = 'ROADMAP';
// 1. SATELLITE:
// Displays photographic tiles.
// 2. ROADMAP:
// Displays the normal, default 2D tiles of Google Maps.
// 3. HYBRID:
// Displays a mix of photographic tiles for prominent features (roads, city names).
// 4. TERRAIN:
// Displays physical tiles for elevation and water features (mountains, rivers, etc.).


// gmap_div_id IS THE ID OF THE DIV IN THE HTML THAT WILL CONTAIN THE MAP
// NOTE: The map will fail to appear if there is no CSS width and height set for this div.
var gmap_div_id = "gmap";


// CLICK EVENT TO SHOW THE LAT/LNG WHERE THE MAP IS CLICKED
// USEFUL DURING DEVELOPMENT
// PREVENTS DOUBLE CLICKING TO ZOOM IN, SO ONLY USE TO GET LAT/LNG DURING DEVELOPMENT
// AND SET IT TO false FOR LIVE SYSTEMS
var click_map_shows_lat_lng = false;
var click_map_shows_lat_lng_display = "span_lat_lng_display";


// POINTER LOCATIONS
// SET THE LatLng OF EACH OF YOUR MAP POINTS
var arr_pointer_location = new Array();
// Tokyo
arr_pointer_location[0] = new google.maps.LatLng(35.711395371053676, 139.73193168640137);
// Kurashiki, Okayama-Ken
arr_pointer_location[1] = new google.maps.LatLng(34.6015631772409, 133.76552939414978);
// Hiroshima
arr_pointer_location[2] = new google.maps.LatLng(34.409742177014195, 132.45563507080078);


// SET WHETHER OR NOT TO DISPLAY THE POP-UP WINDOWS WHEN THE MAP LOADS
var arr_show_info_window_onload = new Array();
arr_show_info_window_onload[0] = false;
arr_show_info_window_onload[1] = false;
arr_show_info_window_onload[2] = false;


// TEXT FOR THE TOOLTIP THAT DISPLAYS WHEN HOVERING OVER THE MARKER
// THIS DOES NOT ALWAYS APPEAR, BUT IS NOT IMPORTANT
var arr_pointer_marker_title = new Array();
arr_pointer_marker_title[0] = "Tokyo";
arr_pointer_marker_title[1] = "Kurashiki, Okayama-Ken";
arr_pointer_marker_title[2] = "Hiroshima";


// HTML FOR THE INFO WINDOW CONTENT
var arr_content_string = new Array();
var info_window_index;

// 0. TOKYO
info_window_index = 0;
arr_content_string[info_window_index]  = '<p class="gmap_info_window gmap_info_window_tokyo">';
arr_content_string[info_window_index] += '<img src="img/geography/city-tokyo.jpg" alt="Tokyo" />';
arr_content_string[info_window_index] += 'Tokyo,<br />'; 
arr_content_string[info_window_index] += 'Japan';
arr_content_string[info_window_index] += '</p>';

// 1. KURASHIKI, OKAYAMA-KEN
info_window_index = 1;
arr_content_string[info_window_index]  = '<p class="gmap_info_window gmap_info_window_kurashiki">';
arr_content_string[info_window_index] += '<img src="img/awaiting_image.gif" alt="Kurashiki" />';
arr_content_string[info_window_index] += 'Kurashiki,<br />'; 
arr_content_string[info_window_index] += 'Okayama-Ken,<br />'; 
arr_content_string[info_window_index] += 'Japan';
arr_content_string[info_window_index] += '</p>';

// 2. HIROSHIMA
info_window_index = 2;
arr_content_string[info_window_index]  = '<p class="gmap_info_window gmap_info_window_hiroshima">';
arr_content_string[info_window_index] += '<img src="img/geography/city-hiroshima.jpg" alt="Hiroshima" />';
arr_content_string[info_window_index] += 'Hiroshima,<br />'; 
arr_content_string[info_window_index] += 'Japan';
arr_content_string[info_window_index] += '</p>';

/* CONFIGURATION ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ END */

