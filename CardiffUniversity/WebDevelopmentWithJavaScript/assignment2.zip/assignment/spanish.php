<?php

header("content-type: Access-Control-Allow-Origin: *");
header("content-type: Access-Control-Allow-Methods: POST");
header("content-type: text/javascript");



    
$menu = array(
    array(
        "course" => "starter",
        "name" => "Chorizo Sausage Rolls",
        "price" => "5.99"
    ),
    array(
        "course" => "starter",
        "name" => "Sardines in Lemon Sauce",
        "price" => "6.99"
    ),
    array(
        "course" => "starter",
        "name" => "Spanish Tortilla",
        "price" => "5.99"
    ),
    array(
        "course" => "starter",
        "name" => "Escabeche",
        "price" => "4.99"
    ),
    array(
        "course" => "main",
        "name" => "Seafood Paella",
        "price" => "13.99"
    ),
    array(
        "course" => "main",
        "name" => "Albondigas Soup",
        "price" => "9.99"
    ),
    array(
        "course" => "main",
        "name" => "Linguine with Mussels",
        "price" => "13.99"
    ),
    array(
        "course" => "main",
        "name" => "Spanish Rice with Shrimp",
        "price" => "11.99"
    ),
    array(
        "course" => "main",
        "name" => "Roasted Red Pepper Salad",
        "price" => "8.99"
    ),
    array(
        "course" => "main",
        "name" => "Chorizo Fritatta",
        "price" => "10.99"
    ),
    array(
        "course" => "main",
        "name" => "Lamb Meatballs",
        "price" => "12.99"
    ),
);


    
//    echo json_encode($obj);


    echo $_GET['callback'] . '(' . json_encode($menu) . ');';

?>